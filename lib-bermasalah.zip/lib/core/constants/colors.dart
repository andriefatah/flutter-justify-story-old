// ignore_for_file: constant_identifier_names

import 'package:flutter/material.dart';

class AppColors {
  static const Color primaryColor = Color(0xff242424);

  static const Color secondaryColor = Color(0xff242424);

  static const Color backgroundColor = Color(0xff191919);
  static const Color buttonTextColor = Color(0xffffffff);
  static const Color textfieldBackgroundColor = Color(0xFFF3F3ED);

  static const Color buttonBackgroundColor = Color(0xff191919);

  static const Color priceColor = Color(0xff557ADB);

  static const Color headingColor = Color(0xff191919);
  static const Color subHeadingColor = Color(0xFF8F8989);
  static const Color bodyTextColor = Color(0xFFB1B1B1);
  static const Color linkTextColor = Color(0xFF000000);

  static const Color accentColor1 = Color(0xff557ADB);
  static const Color accentColor2 = Color(0xffC14949);
  static const Color accentColor3 = Color(0xff95BBF4);

  static const Color dangerColor = Color(0xffEF3826);
  static const Color warningColor = Color(0xffFFA756);
  static const Color infoColor = Color(0xff00B69B);
  static const Color successColor = Color(0xff00B69B);

  static const Color orderIsCanceled = Color(0xffEF3826);
  static const Color orderIsProcessed = Color(0xffFFA756);
  static const Color OrderIsWaiting = Color(0xff00B69B);
  static const Color OrderIsCompleted = Color(0xff00B69B);
}
