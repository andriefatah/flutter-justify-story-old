class Variables {
  static const String appName = "Justify Story App";
  static const String baseUrl = "http://192.168.1.12:8000";
}
