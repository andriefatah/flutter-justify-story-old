import 'package:flutter_reservasi_foto_justify_story_app/data/models/response/auth_response_model.dart';
// import 'package:flutter_reservasi_foto_justify_story_app/data/models/response/user_detail_update_response_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthLocalDataSource {
  Future<void> saveAuthData(AuthResponseModel authResponseModel) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('auth_data', authResponseModel.toJson());
  }

  Future<void> removeAuthData() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('auth_data');
  }

  Future<AuthResponseModel?> getAuthData() async {
    final prefs = await SharedPreferences.getInstance();
    final authData = prefs.getString('auth_data');
    if (authData != null) {
      return AuthResponseModel.fromJson(authData);
    } else {
      return null;
    }
  }

  Future<bool> isUserLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey('auth_data');
  }

  // Future<void> updateAuthData(UserDetailUpdateResponseModel updatedData) async {
  //   final prefs = await SharedPreferences.getInstance();
  //   final authDataString = prefs.getString('auth_data');
  //   if (authDataString != null) {
  //     final authData = AuthResponseModel.fromJson(authDataString);
  //     // Pastikan untuk memperbarui hanya bagian yang diperlukan dari data pengguna
  //     if (authData.user != null && updatedData.user != null) {
  //       authData.user!.name = updatedData.user!.name;
  //       authData.user!.email = updatedData.user!.email;
  //       authData.user!.userDetail = updatedData.user!.userDetail;
  //       // ... update fields lainnya sesuai kebutuhan
  //     }
  //     await prefs.setString('auth_data', authData.toJson());
  //   }
  // }
}
