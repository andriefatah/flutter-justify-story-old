import 'package:flutter/material.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/widget/main_layout.dart';
import 'package:google_fonts/google_fonts.dart';

class SuccessBookingPage extends StatelessWidget {
  final String message;

  const SuccessBookingPage({Key? key, required this.message}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Future.delayed(Duration(seconds: 3), () {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (context) => MainLayout()),
      );
    });

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/images/success.png', width: 150, height: 150),
              SizedBox(height: 20),
              Text(
                'Reservasi Anda Telah Kami Terima!',
                style: GoogleFonts.poppins(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
                textAlign: TextAlign.center,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.of(context).pushReplacement(
                    MaterialPageRoute(builder: (context) => MainLayout()),
                  );
                },
                child: Text(
                  'Kembali ke Beranda',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
