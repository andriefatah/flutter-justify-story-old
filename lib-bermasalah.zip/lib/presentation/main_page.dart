import 'package:flutter/material.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/gallery/pages/detail_gallery_page.dart';
import 'home/pages/home_page.dart';
import 'gallery/pages/gallery_page.dart';
import 'transaction/pages/all_transaction_page.dart';
import 'account/pages/setting_page.dart';
import 'widgets/bottom_navigation.dart';

class MainPage extends StatefulWidget {
  final int initialIndex;

  MainPage({this.initialIndex = 0});

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  late int _selectedIndex;

  @override
  void initState() {
    super.initState();
    _selectedIndex = widget.initialIndex;
  }

  final List<Widget> _pages = [
    HomePage(),
    GalleryPage(),
    AllTransactionPage(),
    SettingPage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Navigator(
        key: GlobalKey<NavigatorState>(),
        onGenerateRoute: (RouteSettings settings) {
          WidgetBuilder builder;
          switch (settings.name) {
            case '/':
              builder = (BuildContext _) => _pages[_selectedIndex];
              break;
            case '/detail_gallery':
              builder = (BuildContext _) =>
                  DetailGalleryPage(index: settings.arguments as int);
              break;
            default:
              throw Exception('Invalid route: ${settings.name}');
          }
          return MaterialPageRoute(builder: builder, settings: settings);
        },
      ),
      bottomNavigationBar: BottomNavigation(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
