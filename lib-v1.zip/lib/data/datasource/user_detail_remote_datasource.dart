import 'dart:convert';

import 'package:dartz/dartz.dart';
import 'package:flutter_reservasi_foto_justify_story_app/core/constants/variables.dart';
import 'package:flutter_reservasi_foto_justify_story_app/data/datasource/auth_local_datasource.dart';
import 'package:flutter_reservasi_foto_justify_story_app/data/models/request/user_detail_update_request_model.dart';
import 'package:flutter_reservasi_foto_justify_story_app/data/models/response/user_detail_response_model.dart';
import 'package:flutter_reservasi_foto_justify_story_app/data/models/response/user_detail_update_response_model.dart';
import 'package:http/http.dart' as http;

class UserDetailRemoteDatasource {
  Future<Either<String, UserDetailResponseModel>> getUserDetail() async {
    final authData = await AuthLocalDataSource().getAuthData();
    if (authData?.user?.id == null) {
      return const Left('User ID tidak ditemukan');
    }
    // print(authData?.user?.id);
    final url = Uri.parse(
        '${Variables.baseUrl}/api/account-details?user_id=${authData?.user?.id}');

    final response = await http.get(
      url,
      headers: {
        // 'Authorization': 'Bearer \${authData.token}',
        'Accept': 'application/json',
      },
    );

    if (response.statusCode == 200) {
      return Right(UserDetailResponseModel.fromMap(json.decode(response.body)));
    } else {
      return Left(response.body.isNotEmpty
          ? json.decode(response.body)
          : 'Gagal mendapatkan data detail user');
    }
  }

  Future<Either<String, UserDetailUpdateResponseModel>> updateUserDetail(
      UserDetailUpdateRequestModel data) async {
    final uri = Uri.parse('${Variables.baseUrl}/api/account-details/update');

    try {
      final response = await http.patch(
        uri,
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: data.toJson(),
      );

      print('Status Code: ${response.statusCode}');
      print('Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final responseData =
            UserDetailUpdateResponseModel.fromJson(response.body);
        return Right(responseData);
      } else {
        return Left('Gagal memperbarui data: ${response.body}');
      }
    } on Exception catch (e) {
      print('Exception occurred: $e');
      return Left('Exception occurred: $e');
    }
  }
}
