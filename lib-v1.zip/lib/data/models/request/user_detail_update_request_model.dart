import 'dart:convert';

class UserDetailUpdateRequestModel {
  final int? userId;
  final String? name;
  final String? email;
  final int? userDetailId;
  final String? jenisKelamin;
  final String? alamat;
  final String? noTelp;

  UserDetailUpdateRequestModel({
    this.userId,
    this.name,
    this.email,
    this.userDetailId,
    this.jenisKelamin,
    this.alamat,
    this.noTelp,
  });

  factory UserDetailUpdateRequestModel.fromJson(String str) =>
      UserDetailUpdateRequestModel.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory UserDetailUpdateRequestModel.fromMap(Map<String, dynamic> json) =>
      UserDetailUpdateRequestModel(
        userId: json["user_id"],
        name: json["name"],
        email: json["email"],
        userDetailId: json["user_detail_id"],
        jenisKelamin: json["jenis_kelamin"],
        alamat: json["alamat"],
        noTelp: json["no_telp"],
      );

  Map<String, dynamic> toMap() => {
        "user_id": userId,
        "name": name,
        "email": email,
        "user_detail_id": userDetailId,
        "jenis_kelamin": jenisKelamin?.toLowerCase(),
        "alamat": alamat,
        "no_telp": noTelp,
      };
}
