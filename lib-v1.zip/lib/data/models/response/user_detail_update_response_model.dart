import 'dart:convert';

class UserDetailUpdateResponseModel {
  final String? message;
  final User? user;

  UserDetailUpdateResponseModel({
    this.message,
    this.user,
  });

  factory UserDetailUpdateResponseModel.fromJson(String str) =>
      UserDetailUpdateResponseModel.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory UserDetailUpdateResponseModel.fromMap(Map<String, dynamic> json) =>
      UserDetailUpdateResponseModel(
        message: json["message"],
        user: json["user"] == null ? null : User.fromMap(json["user"]),
      );

  Map<String, dynamic> toMap() => {
        "message": message,
        "user": user?.toMap(),
      };
}

class User {
  final int? id;
  final String? name;
  final String? email;
  final DateTime? emailVerifiedAt;
  final String? role;
  final int? isActive;
  final DateTime? createdAt;
  final DateTime? updatedAt;
  final UserDetail? userDetail;

  User({
    this.id,
    this.name,
    this.email,
    this.emailVerifiedAt,
    this.role,
    this.isActive,
    this.createdAt,
    this.updatedAt,
    this.userDetail,
  });

  factory User.fromJson(String str) => User.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory User.fromMap(Map<String, dynamic> json) => User(
        id: json["id"],
        name: json["name"],
        email: json["email"],
        emailVerifiedAt: json["email_verified_at"] == null
            ? null
            : DateTime.parse(json["email_verified_at"]),
        role: json["role"],
        isActive: json["is_active"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
        userDetail: json["user_detail"] == null
            ? null
            : UserDetail.fromMap(json["user_detail"]),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "name": name,
        "email": email,
        "email_verified_at": emailVerifiedAt?.toIso8601String(),
        "role": role,
        "is_active": isActive,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
        "user_detail": userDetail?.toMap(),
      };
}

class UserDetail {
  final int? id;
  final String? jenisKelamin;
  final String? alamat;
  final String? noTelp;
  final int? userId;
  final DateTime? createdAt;
  final DateTime? updatedAt;

  UserDetail({
    this.id,
    this.jenisKelamin,
    this.alamat,
    this.noTelp,
    this.userId,
    this.createdAt,
    this.updatedAt,
  });

  factory UserDetail.fromJson(String str) =>
      UserDetail.fromMap(json.decode(str));

  String toJson() => json.encode(toMap());

  factory UserDetail.fromMap(Map<String, dynamic> json) => UserDetail(
        id: json["id"],
        jenisKelamin: json["jenis_kelamin"],
        alamat: json["alamat"],
        noTelp: json["no_telp"],
        userId: json["user_id"],
        createdAt: json["created_at"] == null
            ? null
            : DateTime.parse(json["created_at"]),
        updatedAt: json["updated_at"] == null
            ? null
            : DateTime.parse(json["updated_at"]),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "jenis_kelamin": jenisKelamin,
        "alamat": alamat,
        "no_telp": noTelp,
        "user_id": userId,
        "created_at": createdAt?.toIso8601String(),
        "updated_at": updatedAt?.toIso8601String(),
      };
}
