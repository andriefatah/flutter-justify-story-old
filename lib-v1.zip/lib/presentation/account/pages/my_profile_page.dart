import 'package:flutter/material.dart';
import 'package:flutter_reservasi_foto_justify_story_app/core/components/buttons.dart';
import 'package:flutter_reservasi_foto_justify_story_app/core/components/custom_text_field.dart';
import 'package:flutter_reservasi_foto_justify_story_app/core/constants/colors.dart';
import 'package:flutter_reservasi_foto_justify_story_app/data/datasource/auth_local_datasource.dart';
import 'package:flutter_reservasi_foto_justify_story_app/data/models/request/user_detail_update_request_model.dart';

class MyProfilePage extends StatefulWidget {
  @override
  _MyProfilePageState createState() => _MyProfilePageState();
}

class _MyProfilePageState extends State<MyProfilePage> {
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController addressController = TextEditingController();
  final AuthLocalDataSource _authLocalDataSource = AuthLocalDataSource();
  String? selectedGender;
  int? userDetailId;

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  Future<void> _loadUserData() async {
    final authData = await _authLocalDataSource.getAuthData();
    setState(() {
      nameController.text = authData?.user?.name ?? '';
      emailController.text = authData?.user?.email ?? '';
      phoneController.text = authData?.user?.userDetail?.noTelp ?? '';
      addressController.text = authData?.user?.userDetail?.alamat ?? '';
      selectedGender = authData?.user?.userDetail?.jenisKelamin;
      userDetailId = authData?.user?.userDetail?.id;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profil Saya'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                const SizedBox(height: 20),
                buildProfileForm(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildProfileForm() {
    return Column(
      children: [
        CustomTextField(
          controller: nameController,
          label: 'Nama',
          keyboardType: TextInputType.text,
          prefixIcon: const Icon(Icons.person),
          borderRadius: 0,
          contentPadding: const EdgeInsets.symmetric(
            vertical: 20.0,
            horizontal: 15.0,
          ),
        ),
        const SizedBox(height: 10),
        CustomTextField(
          controller: emailController,
          label: 'Email',
          keyboardType: TextInputType.emailAddress,
          prefixIcon: const Icon(Icons.email),
          borderRadius: 0,
          contentPadding: const EdgeInsets.symmetric(
            vertical: 20.0,
            horizontal: 15.0,
          ),
        ),
        const SizedBox(height: 10),
        buildGenderDropdown(),
        const SizedBox(height: 10),
        CustomTextField(
          controller: phoneController,
          label: 'No. Telepon',
          keyboardType: TextInputType.phone,
          prefixIcon: const Icon(Icons.phone),
          borderRadius: 0,
          contentPadding: const EdgeInsets.symmetric(
            vertical: 20.0,
            horizontal: 15.0,
          ),
        ),
        const SizedBox(height: 10),
        CustomTextField(
          controller: addressController,
          label: 'Alamat',
          keyboardType: TextInputType.text,
          prefixIcon: const Icon(Icons.home),
          borderRadius: 0,
          contentPadding: const EdgeInsets.symmetric(
            vertical: 20.0,
            horizontal: 15.0,
          ),
        ),
        const SizedBox(height: 20),
        Button.filled(
          onPressed: () async {
            final authData = await _authLocalDataSource
                .getAuthData(); // Mendapatkan data autentikasi
            if (userDetailId != null && authData?.user != null) {
              final data = UserDetailUpdateRequestModel(
                userId: authData?.user!.id!,
                name: nameController.text,
                email: emailController.text,
                jenisKelamin: selectedGender,
                noTelp: phoneController.text,
                alamat: addressController.text,
                userDetailId: userDetailId,
              );

              // Print semua value di data
              print('User ID: ${data.userId}');
              print('Nama: ${data.name}');
              print('Email: ${data.email}');
              print('Jenis Kelamin: ${data.jenisKelamin}');
              print('No. Telepon: ${data.noTelp}');
              print('Alamat: ${data.alamat}');
              print('User Detail ID: ${data.userDetailId}');

              // Add your update logic here
            } else {
              print('userDetailId or authData is null');
            }
          },
          label: 'Ubah Data',
          width: 400,
          height: 45.0,
          borderRadius: 15,
          fontSize: 18.0,
        ),
      ],
    );
  }

  Widget buildGenderDropdown() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Jenis Kelamin',
          style: TextStyle(
            fontSize: 16,
            color: AppColors.subHeadingColor,
          ),
        ),
        SizedBox(height: 8),
        DropdownButtonFormField<String>(
          value: selectedGender,
          onChanged: (String? newValue) {
            setState(() {
              selectedGender = newValue;
            });
          },
          items: <String>['laki-laki', 'perempuan']
              .map<DropdownMenuItem<String>>((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Text(value.capitalize()),
            );
          }).toList(),
          decoration: InputDecoration(
            prefixIcon: Icon(Icons.person),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16.0),
              borderSide: BorderSide.none,
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(16.0),
              borderSide: BorderSide.none,
            ),
            filled: true,
            fillColor: Color(0xFFF3F3ED),
            contentPadding: EdgeInsets.symmetric(
              vertical: 20.0,
              horizontal: 15.0,
            ),
          ),
        ),
      ],
    );
  }
}

extension on String? {
  String capitalize() {
    return this != null ? '${this![0].toUpperCase()}${this!.substring(1)}' : '';
  }
}
