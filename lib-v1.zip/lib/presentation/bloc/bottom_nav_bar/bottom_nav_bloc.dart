import 'package:flutter_bloc/flutter_bloc.dart';
import 'bottom_nav_event.dart';
import 'bottom_nav_state.dart';

// Bloc untuk mengelola state dari BottomNavigationBar.
class BottomNavBloc extends Bloc<BottomNavEvent, BottomNavState> {
  BottomNavBloc() : super(BottomNavState(0)) {
    on<BottomNavEvent>((event, emit) {
      switch (event) {
        case BottomNavEvent.beranda:
          emit(BottomNavState(0));
          break;
        case BottomNavEvent.galeri:
          emit(BottomNavState(1));
          break;
        case BottomNavEvent.transaksi:
          emit(BottomNavState(2));
          break;
        case BottomNavEvent.pengguna:
          emit(BottomNavState(3));
          break;
        case BottomNavEvent.tentangKami:
          emit(BottomNavState(4));
          break;
      }
    });
  }
}
