enum BottomNavEvent {
  beranda,
  galeri,
  transaksi,
  pengguna,
  tentangKami,
}
