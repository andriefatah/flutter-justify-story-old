// State untuk BottomNavigationBar yang menyimpan index dari tab yang dipilih.
class BottomNavState {
  final int selectedIndex;

  BottomNavState(this.selectedIndex);

  List<Object> get props => [selectedIndex];
}
