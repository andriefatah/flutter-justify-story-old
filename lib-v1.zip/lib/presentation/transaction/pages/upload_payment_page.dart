import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_reservasi_foto_justify_story_app/core/components/buttons.dart';

class UploadPaymentPage extends StatefulWidget {
  final int transactionId;
  final String selectedMethodName;
  final double selectedPaymentAmount;

  const UploadPaymentPage({
    Key? key,
    required this.transactionId,
    required this.selectedMethodName,
    required this.selectedPaymentAmount,
  }) : super(key: key);

  @override
  _UploadPaymentPageState createState() => _UploadPaymentPageState();
}

class _UploadPaymentPageState extends State<UploadPaymentPage> {
  File? _selectedImage;
  final TextEditingController _noteController = TextEditingController();
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImage(ImageSource source) async {
    final pickedFile = await _picker.pickImage(source: source);

    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  void _uploadPayment() {
    if (_selectedImage == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Mohon unggah bukti pembayaran terlebih dahulu'),
        ),
      );
      return;
    }

    // Implementasi logika untuk mengunggah pembayaran
    // Mengirim data ke API

    print('Transaction ID: ${widget.transactionId}');
    print('Selected Payment Method: ${widget.selectedMethodName}');
    print('Jumlah Pembayaran: ${widget.selectedPaymentAmount}');
    print('Catatan: ${_noteController.text}');
    print('Gambar Bukti Pembayaran: ${_selectedImage!.path}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Upload Pembayaran',
          style: GoogleFonts.poppins(fontWeight: FontWeight.w600),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Detail Pembayaran',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16.0),
            Text(
              'Transaction ID: ${widget.transactionId}',
              style: GoogleFonts.poppins(),
            ),
            const SizedBox(height: 8.0),
            Text(
              'Metode Pembayaran: ${widget.selectedMethodName}',
              style: GoogleFonts.poppins(),
            ),
            const SizedBox(height: 8.0),
            Text(
              'Jumlah Pembayaran: Rp. ${widget.selectedPaymentAmount.toStringAsFixed(0)}',
              style: GoogleFonts.poppins(),
            ),
            const SizedBox(height: 32.0),
            Text(
              'Upload Bukti Pembayaran',
              style: GoogleFonts.poppins(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16.0),
            _buildFileUploadField(),
            const SizedBox(height: 16.0),
            _buildNoteField(),
            const SizedBox(height: 32.0),
            Button.filled(
              onPressed: _uploadPayment,
              label: 'Unggah Pembayaran',
              height: 45.0,
              borderRadius: 20.0,
              fontSize: 14.0,
              color: Colors.black,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFileUploadField() {
    return GestureDetector(
      onTap: () {
        showModalBottomSheet(
          context: context,
          builder: (context) => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: Icon(Icons.camera_alt),
                title: Text('Ambil dari Kamera'),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: Icon(Icons.photo_library),
                title: Text('Pilih dari Galeri'),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
            ],
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(12.0),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: Row(
          children: [
            Icon(Icons.file_upload),
            const SizedBox(width: 12.0),
            Expanded(
              child: Text(
                _selectedImage == null
                    ? 'Unggah File (dari Kamera atau Galeri)'
                    : 'Gambar terpilih: ${_selectedImage!.path.split('/').last}',
                style: GoogleFonts.poppins(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNoteField() {
    return TextField(
      controller: _noteController,
      decoration: InputDecoration(
        labelText: 'Catatan',
        hintText: 'Tambahkan catatan (opsional)',
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8.0),
        ),
      ),
      maxLines: 3,
    );
  }
}
