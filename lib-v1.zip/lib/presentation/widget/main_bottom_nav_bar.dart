// ignore_for_file: deprecated_member_use

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/bloc/bottom_nav_bar/bottom_nav_bloc.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/bloc/bottom_nav_bar/bottom_nav_event.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/bloc/bottom_nav_bar/bottom_nav_state.dart';

class MainBottomNavBar extends StatelessWidget {
  const MainBottomNavBar({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<BottomNavBloc, BottomNavState>(
      builder: (context, state) {
        return BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.black,
          selectedItemColor: Colors.white,
          unselectedItemColor: Colors.white.withOpacity(0.6),
          selectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.normal,
            fontFamily: 'Montserrat', // Menetapkan font family ke Montserrat
          ),
          unselectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.w400,
            fontFamily: 'Montserrat', // Menetapkan font family ke Montserrat
          ),
          currentIndex: state.selectedIndex,
          onTap: (index) {
            BottomNavEvent event = BottomNavEvent.beranda;
            switch (index) {
              case 0:
                event = BottomNavEvent.beranda;
                break;
              case 1:
                event = BottomNavEvent.galeri;
                break;
              case 2:
                event = BottomNavEvent.transaksi;
                break;
              case 3:
                event = BottomNavEvent.pengguna;
                break;
              case 4:
                event = BottomNavEvent.tentangKami;
                break;
            }
            // print('Event to add: $event'); // Debug event to add
            context.read<BottomNavBloc>().add(event);
          },
          items: [
            BottomNavigationBarItem(
              icon: SvgPicture.asset('assets/icons/home.svg',
                  color: state.selectedIndex == 0
                      ? Colors.white
                      : Colors.white.withOpacity(0.6)),
              label: 'Beranda',
            ),
            BottomNavigationBarItem(
              icon: SvgPicture.asset('assets/icons/gallery.svg',
                  color: state.selectedIndex == 1
                      ? Colors.white
                      : Colors.white.withOpacity(0.6)),
              label: 'Galeri',
            ),
            BottomNavigationBarItem(
              icon: SvgPicture.asset('assets/icons/transaction.svg',
                  color: state.selectedIndex == 2
                      ? Colors.white
                      : Colors.white.withOpacity(0.6)),
              label: 'Transaksi',
            ),
            BottomNavigationBarItem(
              icon: SvgPicture.asset('assets/icons/user.svg',
                  color: state.selectedIndex == 3
                      ? Colors.white
                      : Colors.white.withOpacity(0.6)),
              label: 'Pengguna',
            ),
          ],
        );
      },
    );
  }
}
