import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/account/pages/about_me_page.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/account/pages/setting_page.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/bloc/bottom_nav_bar/bottom_nav_bloc.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/bloc/bottom_nav_bar/bottom_nav_state.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/gallery/pages/gallery_page.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/home/pages/home_page.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/transaction/pages/all_transaction_page.dart';
import 'package:flutter_reservasi_foto_justify_story_app/presentation/widget/main_bottom_nav_bar.dart';

class MainLayout extends StatelessWidget {
  const MainLayout({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider<BottomNavBloc>(
      create: (context) => BottomNavBloc(),
      child: Scaffold(
        body: BlocBuilder<BottomNavBloc, BottomNavState>(
          builder: (context, state) {
            // IndexedStack untuk mempertahankan state dari setiap halaman
            return IndexedStack(
              index: state.selectedIndex,
              children: [
                const HomePage(),
                const GalleryPage(),
                const AllTransactionPage(),
                SettingPage(),
                const AboutMePage(),
                // Tambahkan halaman lain sesuai dengan struktur folder Anda
              ],
            );
          },
        ),
        bottomNavigationBar: MainBottomNavBar(),
      ),
    );
  }
}
